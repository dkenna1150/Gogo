<?php

$dbhost = 'localhost'; 
$dbname = 'test'; 
$dbuser = 'root'; 
$dbpass = ''; 
$connection = new mysqli($dbhost, $dbuser, $dbpass, $dbname);
if ($connection->connect_error) die($connection->connect_error);


