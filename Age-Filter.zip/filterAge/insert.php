<?php
//THIS IS THE MAIN TIME FETCH CURRENT TIME 
$waktu_now = date("Y-m-d H:i:s");
$waktu_now_a = date("Y");
//END OF FETCHING CURRENT TIME.

/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
$mysqli = new mysqli("localhost", "root", "", "test");
 
// Check connection
if($mysqli === false){
    die("ERROR: Could not connect. " . $mysqli->connect_error);
}
 
// Escape user inputs for security
//STATUS:- THIS IS COMING FROM AN INPUT TO CHECH AUTHENTICATION
$first_name = $mysqli->real_escape_string($_POST['status']);
$day = $mysqli->real_escape_string($_POST['dy']);
$month = $mysqli->real_escape_string($_POST['mo']);
$year = $mysqli->real_escape_string($_POST['yr']);

//WHY THIS WAKTU IS NOT...
// $yr = "2001";
$age_b = $waktu_now - $year;
$age = $age_b - 1;
$waktu = $waktu_now;
// echo $age;
//filter from age.
// echo $day."<br>";
// Attempt insert query execution
$sql = "INSERT INTO feeds(status, day, month, year, age, waktu) VALUES 
('$first_name', '$day', '$month', '$year', '$age', '$waktu')";
if($mysqli->query($sql) === true){
    echo "Records inserted successfully.";
    header("location: index.php");
} else{
    echo "ERROR: Could not able to execute $sql. " . $mysqli->error;
}
 
// Close connection
$mysqli->close();
?>