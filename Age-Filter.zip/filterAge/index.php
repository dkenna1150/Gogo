<?php
//include_once 'function.php';
include_once 'connect.php';
?>
<head>
    <title> filter</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>

    <form method="post" id="create" action="insert.php">
      <b style="color: white; margin: 10px;">Create New Employee</b>
    <input type="text" size="40" name="status" placeholder="Employee Name"/>
    <br><br>
    <b style="color: white; margin: 10px;">Date Of Birth</b>
    <select name="dy">
      <option>date..</option>
      <option>1</option>
      <option>2</option>
      <option>4</option>
      <option>5</option>
    </select> &nbsp;&nbsp;
     <select name="mo">
      <option>month..</option>
      <option>1</option>
      <option>2</option>
      <option>4</option>
      <option>5</option>
      <option>6</option>
      <option>7</option>
      <option>8</option>
      <option>9</option>
      <option>10</option>
      <option>11</option>
      <option>12</option>
    </select>
    &nbsp;&nbsp;
     <input type="text" name="yr" placeholder="year only. eg 1993">
     <br><br>


    <input type="submit" value="submit">
</form>
    
    <aside class="one">
        <!-- <em>thanks bro,i really appreciate your work and codes,its simple and clean,but am workin on these employee
        files,i want the admin to be able to select emoloyers at any particular age he/she wishes, your code kinda 
        solves the problem but it doesnt look cool selectin it from <b>dd/mm/yyyy </b> rather 20,23,39,40 etc...thanks 
        </em> -->
        <em>thank you once again for your support.<br>
        make sure you put what is in the dbc->tbl->column->age.
       <br></em><br>

        <a href="index.php">Home</a>
          <style>
            table,tr,th,td{
              border: 1px solid blue;
            }
            table{
            }
          </style>
           <?php
   //SEARCH IS TO DECLARE WE ARE USING A KNOWN VARIABLE.
   if (isset($_POST['search'])) {
    # code...
    //GET POSTED INFORMATION FROM OUR FORM.
    $from_date=$_POST['txtStartDate'];
    $to_date=$_POST['txtEndDate'];
    
    $txtStartDate = $from_date;
    $txtEndDate = $to_date;



    
   //BRAIN TO CHECK AND SEARCH FOR AVAILABLE DATAS OR IF SAME INFORMATION IS 
   //AVAILABLE DISPLAY RESULT.
$query = "Select * FROM feeds WHERE age BETWEEN '$txtStartDate' and '$txtEndDate' ORDER BY age";
   $search_result = filterTable($query);
   }else{
   $query = "SELECT * FROM feeds";
   $search_result = filterTable($query);
   }
   //CHECK DBCONNECTION FOR AVAILABILITY AND IF SUCCESSFUL DISPLAY RESULT.
   function filterTable($query){
    $connect = mysqli_connect("localhost","root","","test");
    $filter_Result = mysqli_query($connect, $query);
    return $filter_Result;
   }
  ?>
       <form method="POST" action="" class="form">
            <p class="p">select employees with ages from
            <input type="text" name="txtStartDate" size="2" placeholder="startDate"></p>
            <p class="p">to
            <input type="text" name="txtEndDate" size="2" placeholder="txtEndDate"></p>
     <input type="submit" name="search" value="Filter"><br><br>
            
        </form>

      <?php echo "<table>
      <tr>
        <th>Id</th>
        <th>Comment</th>
        <th>Date</th>
        <th>Age</th>
      </tr>";
      ?>
      <?php while($row = mysqli_fetch_array($search_result)):?>
       <tr>
        <td><?php echo $row['id_feeds']; ?></td>
        <td><?php echo $row['status']; ?></td>
        <td><?php echo $row['waktu']; ?></td>
        <td><?php echo $row['age']; ?></td>
       </tr>
      <?php endwhile; ?>
      </table> 
    </aside>
   <aside class="one">
       <?php
        //   DISPLAY CODE HERE
   function timeAgo($time_ago){
            $cur_time = time();
            $time_elapsed = $cur_time - $time_ago;
            $seconds = $time_elapsed;
            $minutes = round($time_elapsed / 60);
            $hours   = round($time_elapsed / 3600);
            $days    = round($time_elapsed / 86400);
            $weeks   = round($time_elapsed / 604800);
            $months  = round($time_elapsed / 2600640);
            $years   = round($time_elapsed / 31207680);
            //seconds
            if ($seconds <= 60) {
              echo "$seconds seconds ago";
            }
            //minutes
            else if($minutes <= 60) {
                if($minutes == 1){
                  echo "one minutes ago";
                }else{
                  echo "$minutes minutes ago";
                }
            }
            //hours
            else if ($hours <=24) {
               if ($hours==1) {
                  echo "an hour ago";
               }else{
                  echo "$hours hours ago";
               }
            }
            //days
            else if ($days <=7) {
                if ($days==1) {
                  echo "yesterday";
                }else{
                  echo "$days days ago";
                }
            }
            //weeks
            else if($weeks <=4.3) {
                if($weeks==1){
                  echo "a week ago";
                }else{
                  echo "$weeks weeks ago";
                }
            }
            //months
            else if ($months <=12) {
                if ($months==1) {
                     echo "a month ago";
                }else{
                  echo "$months months ago";
                }
            }
            //years
            else{
                if ($years==1) {
                  echo "one year ago";
                }else{
                  echo "$years years ago";
                }
            }
      }

      $take = $connection->query("SELECT * FROM feeds ORDER BY id_feeds DESC");
      $count = $take->num_rows;
      if($count){
        while ($print = $take->fetch_assoc()) {
          // echo "<br>";
          echo "<span class='disp'>".$print['status']."</span>";
          echo "<br>";
          $waktu = $print['waktu'];
          $time_ago = strtotime($waktu);
          echo "<span class='disp'>".timeAgo($time_ago)."</span>";
          echo '<br><br>';
        }
      }else{
        echo "Belum ada data!";
      } ?>
    </aside>
    
    <script>
        var ln = document.getElementsByClassName('aa');
        var ln.onclick =function(){
            alert('oop');
        };
           
        
        </script>
</body>