sql dbname->user.sql 
try and import. 
then customize as u see fit.
note it is not to be resold.
strictly for projects(use) not for resold purposes.
 #thank u for ur compliance.